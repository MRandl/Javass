package ch.epfl.javass.jass;

import ch.epfl.javass.gui.HandBean;
import javafx.collections.ListChangeListener;

import static ch.epfl.javass.jass.Card.*;
import static ch.epfl.javass.jass.Card.Color.*;
import static ch.epfl.javass.jass.Card.Rank.*;

/* /!\ IRRELEVANT DEBUGGING CLASS */
public class Main {
    public static void main(String[] args){
        HandBean hb = new HandBean();
        ListChangeListener<Card> listener = System.out::println;
        hb.getPlayableCards().addListener(listener);

        CardSet h = CardSet.EMPTY
                .add(of(SPADE, SIX))
                .add(of(SPADE, NINE))
                .add(of(SPADE, JACK))
                .add(of(HEART, SEVEN))
                .add(of(HEART, ACE))
                .add(of(DIAMOND, KING))
                .add(of(DIAMOND, ACE))
                .add(of(CLUB, TEN))
                .add(of(CLUB, QUEEN));
        hb.setPlayableCards(h);
        while (! h.isEmpty()) {
            h = h.remove(h.get(h.size()-1));
            hb.setPlayableCards(h);
        }
    }
}
