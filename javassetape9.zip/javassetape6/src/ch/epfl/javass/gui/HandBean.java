package ch.epfl.javass.gui;

import ch.epfl.javass.jass.Card;
import ch.epfl.javass.jass.CardSet;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public final class HandBean {

    private ObservableList<Card> hand = FXCollections.observableArrayList();
    private ObservableList<Card> playableCards = FXCollections.observableArrayList();

    public void setHand(CardSet c){
        obsListSetter(c, hand);
    }

    public ObservableList<Card> getHand() {
        return hand;
    }

    public void setPlayableCards(CardSet c){
        obsListSetter(c, playableCards);
    }

    private void obsListSetter(CardSet c, ObservableList<Card> observableList) {
        if(c.size() == 9) {
            observableList.clear(); //observableList is a difficult type to work with,
                                    //clearing is required here to avoid both exceptions
                                    //and size change in the list
            for (int i = 0; i < c.size(); ++i)
                observableList.add(i, c.get(i));
            return;
        }
        for(int i = 0; i < observableList.size(); ++i)
            if(!(observableList.get(i) == null || c.contains(observableList.get(i))))
                /*not null because the contains() call will throw an exception otherwise*/
                observableList.set(i, null);
    }

    public ObservableList<Card> getPlayableCards() {
        return playableCards;
    }




}

