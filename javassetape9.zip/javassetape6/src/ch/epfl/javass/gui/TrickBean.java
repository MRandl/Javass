package ch.epfl.javass.gui;

import ch.epfl.javass.jass.Card;
import ch.epfl.javass.jass.PlayerId;
import ch.epfl.javass.jass.Trick;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableMap;

public final class TrickBean {

    private SimpleObjectProperty<Card.Color> trump = new SimpleObjectProperty<>();
    private ObservableMap<PlayerId, Card> trick = FXCollections.observableHashMap();
    private SimpleObjectProperty<PlayerId> winningPlayer = new SimpleObjectProperty<>();

    public void setTrump(Card.Color color){
        trump.set(color);
    }

    public ReadOnlyObjectProperty<Card.Color> getTrump(){
        return trump;
    }

    public void setTrick(Trick t){
        for(PlayerId p : PlayerId.ALL){
            if(t.size() > p.ordinal()) {
                trick.put(p, t.card(p.ordinal()));
            } else {
                trick.put(p, null);
            }
        }
        winningPlayer.set(t.size() == 0 ? null : t.winningPlayer());
    }

    public ObservableMap<PlayerId, Card> getTrick() {
        return trick;
    }

    public SimpleObjectProperty<PlayerId> getWinningPlayer() {
        return winningPlayer;
    }
}
