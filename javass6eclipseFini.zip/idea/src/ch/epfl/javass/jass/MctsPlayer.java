package ch.epfl.javass.jass;

import java.util.ArrayList;
import java.util.List;
import java.util.SplittableRandom;

public class MctsPlayer implements Player{

    public MctsPlayer(PlayerId ownId, long rngSeed, int iterations) {
        if(iterations < 9) throw new IllegalArgumentException();
        ownName = ownId;
        rng = new SplittableRandom(rngSeed);

        this.iterations = iterations;
    }

    private PlayerId ownName;
    private SplittableRandom rng;
    private int iterations;

    private class Node{
        private TurnState ts;
        private Node[] children;
        private int bigS = 0;
        private int bigN = 0;
        private int numberOfChildren = 0;
        private CardSet playableCards;
        private PlayerId PlayerThatPlayedThisNode;
        private PlayerId PlayerThatPlayedLastNode;
        private CardSet hand;


        public Node(TurnState t, CardSet hand, PlayerId player, PlayerId fatherPlayer){
            ts = t;
            this.hand = hand;
            PlayerId next;
            if(ts.trick().isFull())
                ts = ts.withTrickCollected();
            next = ts.nextPlayer();

            if(next == ownName)
                playableCards = ts.trick().playableCards(hand.intersection(ts.unplayedCards()));
            else
                playableCards = ts.unplayedCards().difference(hand);
            children = new Node[playableCards.size()];
            PlayerThatPlayedThisNode = player;
            PlayerThatPlayedLastNode = fatherPlayer;
        }

        private Node AddASon(){
            PlayerId sonPlayer;
            try{
                sonPlayer = ts.nextPlayer();
            } catch (IllegalStateException e){
                sonPlayer = ts.withTrickCollected().nextPlayer();
            }
            if(ts.trick().isFull())
                ts = ts.withTrickCollected();
            Node k = new Node(ts.withNewCardPlayed(playableCards.get(numberOfChildren)), hand, sonPlayer, PlayerThatPlayedThisNode);
            children[numberOfChildren] = k;
            ++numberOfChildren;
            return k;

        }


        private int selectBestSon(int c) {
            if(numberOfChildren == 0) {
                return -1;
            }
            int indexOfBest = 0;
            for(int i = 0; i < numberOfChildren; ++i){
                if(value(c,indexOfBest) < value(c,i)) {
                    indexOfBest = i;
                }
            }
            return indexOfBest;
        }


        private double value(double c, int i) {
            if(children[i] == null)
                return -1;
            if(children[i].bigN ==  0)
                return Double.MAX_VALUE;
            if(bigN == 0 || bigN == 1)
                return ((double)children[i].bigS/(double)children[i].bigN);
            double result = ((double)children[i].bigS/(double)children[i].bigN) + c * Math.sqrt((2*Math.log(bigN))/children[i].bigN);
            return result;
        }

        private List<Node> addValidDescendant(){
            boolean mustContinue = true;
            List<Node> list = new ArrayList<>();
            Node currentFather = this;
            while(mustContinue) {
                if (currentFather.numberOfChildren < currentFather.playableCards.size()) {
                    Node l = currentFather.AddASon();
                    list.add(l);
                    mustContinue = false;
                } else if (currentFather.playableCards.size() == 0) {
                    break;
                } else {
                    currentFather = currentFather.children[currentFather.selectBestSon(40)];
                    list.add(currentFather);
                }
            }
            return list;

        }
    }



    @Override
    public Card cardToPlay(TurnState state, CardSet hand) {
        Node father = new Node(state, hand, PlayerId.ALL.get((PlayerId.ALL.indexOf(ownName)+3)%4), null);
        for(int i = 0; i < iterations; ++i) {
            List<Node> list = father.addValidDescendant();

            Node addedNode = list.get(list.size()-1);
            Score nodeScore = randomlyEvaluate(addedNode, hand);
            for(Node node : list){
                node.bigS += nodeScore.totalPoints(node.PlayerThatPlayedThisNode.team());
                ++node.bigN;
            }

        }
        return father.ts.unplayedCards().difference(father.children[father.selectBestSon(0)].ts.unplayedCards()).get(0);
    }

    public Score randomlyEvaluate(Node n, CardSet hand) {
        TurnState tempTs = n.ts;

        CardSet ownPlayerHand = hand.difference(n.ts.unplayedCards().complement());
        CardSet playableOther = tempTs.unplayedCards().difference(hand);

        while (!tempTs.isTerminal()) {
            Card cardToPlay;
            if (tempTs.trick().isFull()) {
                tempTs = tempTs.withTrickCollected();

            }

            if (tempTs.nextPlayer() == ownName) {
                CardSet playable = tempTs.trick().playableCards(ownPlayerHand);
                cardToPlay = playable.get(rng.nextInt(playable.size()));
                ownPlayerHand = ownPlayerHand.remove(cardToPlay);
            } else {
                CardSet playable = tempTs.trick().playableCards(playableOther);
                cardToPlay = playable.get(rng.nextInt(playable.size()));
                playableOther = playableOther.remove(cardToPlay);
            }

            tempTs = tempTs.withNewCardPlayed(cardToPlay);

            if (tempTs.trick().isLast() && tempTs.trick().isFull()) {
                tempTs = tempTs.withTrickCollected();
            }

        }
        return tempTs.score();
    }

}
