package ch.epfl.javass.jass;

import java.util.Map;

import ch.epfl.javass.jass.Card.Color;

public final class PacedPlayer implements Player {
    
    private Player underLy;
    private double minTime;

    public PacedPlayer(Player underlyingPlayer, double minTime) {
        this.underLy = underlyingPlayer;
        this.minTime =1000* minTime;
    }
    
    @Override
    public Card cardToPlay(TurnState state, CardSet hand) {
        long begin = System.currentTimeMillis();
        Card result = underLy.cardToPlay(state, hand);
        long end = System.currentTimeMillis();
        if(end-begin < minTime) {
            try {
                Thread.sleep((long) (minTime - (end - begin)));
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return result;
    }
    
    public void setPlayers(PlayerId ownId, Map<PlayerId, String> playerNames) {
        underLy.setPlayers(ownId, playerNames);
    }
    
    public void updateHand(CardSet newHand) {
        underLy.updateHand(newHand);
    }
    
    public void setTrump(Color trump) {
        underLy.setTrump(trump);
    }   
    
    public void updateTrick(Trick newTrick) {
        underLy.updateTrick(newTrick);
    }
 
    public void updateScore(Score score) {
        underLy.updateScore(score);
    }
    
    public void setWinningTeam(TeamId winningTeam) {
        underLy.setWinningTeam(winningTeam);
    }

}
