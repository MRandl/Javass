package ch.epfl.javass.jass;


import java.util.Random;

/**
 * @author Mathis Randl
 *
 */
public class Main {
// /!\ IRRELEVANT DEBUGGING CLASS /!\
    public static void main(String[] args) {
        System.out.println(Trick.ofPacked(838860799));
    }
}
