package ch.epfl.javass.jass;


/**
 * @author Mathis Randl
 *
 */
public class Main {
// /!\ IRRELEVANT DEBUGGING CLASS /!\
    public static void main(String[] args) {
        System.out.println(CardSet.ofPacked(0b10000001000000000000000000000000000000000L));
        
        System.out.println(Trick.ofPacked(0b10110111111111110111100101000111));
        
    }
}
