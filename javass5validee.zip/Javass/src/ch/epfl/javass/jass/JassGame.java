package ch.epfl.javass.jass;

import java.util.*;

import ch.epfl.javass.jass.Card.Color;
import ch.epfl.javass.jass.Card.Rank;

public final class JassGame {
    public JassGame(long rngSeed, Map<PlayerId, Player> players, Map<PlayerId, String> playerNames) {
        Random rng = new Random(rngSeed);
        this.shuffleRng = new Random(rng.nextLong());
        this.trumpRng = new Random(rng.nextLong());
        this.score = Score.INITIAL;
        this.players = Collections.unmodifiableMap(new EnumMap<>(players));
        this.names = Collections.unmodifiableMap(new EnumMap<>(playerNames));
    }
    
    private Map<PlayerId, String> names;
    private Map<PlayerId, Player> players;
    private boolean isNewGame = true;
    private Score score;
    private long[] cards = new long[4];
    private Random shuffleRng;
    private Random trumpRng;
    private TurnState turnstate;
    private Color currentTrump;
    private PlayerId playerToBegin = PlayerId.PLAYER_1;

    
    public boolean isGameOver() {
        return score.totalPoints(TeamId.TEAM_1) >= Jass.WINNING_POINTS || 
               score.totalPoints(TeamId.TEAM_2) >= Jass.WINNING_POINTS;
    }
    
 
    
    
    private void deckShuffler() {
        List<Card> deck = new LinkedList<>();
        for(int color = 0; color < 4; ++color)
            for(int rank = 0; rank < 9; ++ rank)
                deck.add(Card.of(Color.ALL.get(color), Rank.ALL.get(rank)));
        Collections.shuffle(deck, shuffleRng);
        for(short i = 0; i < 4; ++i)
            cards[i] = CardSet.of(deck.subList(i*Jass.HAND_SIZE,(i+1)*Jass.HAND_SIZE)).packed();
    }
    
    private void trumpShuffle() {
        currentTrump = Color.ALL.get(trumpRng.nextInt(4));
    }
    
    private void updateThemPlayers() {
        for(PlayerId play : PlayerId.ALL) {
            players.get(play).updateTrick(turnstate.trick());
        }
    }
    
    private void setupGame() {
        this.score = Score.INITIAL;
        deckShuffler();
        trumpShuffle();
        for(short i = 0; i < 4; ++i) {
            if((cards[i] & PackedCardSet.singleton(Card.of(Color.DIAMOND, Rank.SEVEN).packed())) != 0) {
                playerToBegin = PlayerId.ALL.get(i);
             }
        }
        
        this.turnstate = TurnState.initial(currentTrump, score, playerToBegin);
        
        for(PlayerId play : PlayerId.ALL) {
           players.get(play).setPlayers(play, names);
           players.get(play).updateHand(CardSet.ofPacked(cards[PlayerId.ALL.indexOf(play)]));
           players.get(play).setTrump(currentTrump);
           players.get(play).updateScore(score);
           players.get(play).updateTrick(turnstate.trick());
        }
    }
    
    private void goToNewTrick() {
        turnstate = turnstate.withTrickCollected();

        score = turnstate.score();
        if(!turnstate.isTerminal())
        for(PlayerId play : PlayerId.ALL) {
            players.get(play).updateScore(score);
        }


        if(!(turnstate.packedTrick() == -1))
        updateThemPlayers();
        
                
    }
    
    private void generateNewTurnSet() {
        deckShuffler();
        trumpShuffle();
        for(PlayerId play : PlayerId.ALL)
            players.get(play).setTrump(currentTrump);
        this.playerToBegin = PlayerId.ALL.get((PlayerId.ALL.indexOf(playerToBegin)+1)%4);
        turnstate = TurnState.initial(currentTrump, score.nextTurn(), playerToBegin);
        for(PlayerId play : PlayerId.ALL) {
            players.get(play).updateScore(score.nextTurn());
            players.get(play).updateTrick(turnstate.trick());
        }
    }
    
    
    private void playersPlay() {
     
        while(!turnstate.trick().isFull()) {
           
            
            PlayerId p = turnstate.nextPlayer();
            Card c = players.get(p).cardToPlay(turnstate, CardSet.ofPacked(cards[p.ordinal()]));

            players.get(p).updateHand(CardSet.ofPacked(cards[PlayerId.ALL.indexOf(p)]).remove(c));
            cards[PlayerId.ALL.indexOf(p)] = PackedCardSet.remove(cards[PlayerId.ALL.indexOf(p)], c.packed());
            turnstate = turnstate.withNewCardPlayed(c);

            for(PlayerId play : PlayerId.ALL)
                players.get(play).updateTrick(turnstate.trick());
        }
        
    }
      
    public void advanceToEndOfNextTrick() {
        if (gameOver()) 
            return;

        if(isNewGame) {
            isNewGame = false;
            setupGame();
            
        } else {
            goToNewTrick();
        }

        if(turnstate.packedTrick() == PackedTrick.INVALID) 
            generateNewTurnSet();

        if (gameOver()) 
            return;

        playersPlay();

        
    }

    private boolean gameOver() {
        if(isGameOver()) {
            for(PlayerId p: PlayerId.ALL){
                players.get(p).setWinningTeam(turnstate.score().totalPoints(TeamId.TEAM_1) >
                                              turnstate.score().totalPoints(TeamId.TEAM_2) ?
                        TeamId.TEAM_1 : TeamId.TEAM_2);
            }
            return true;
        }
        return false;
    }

}
