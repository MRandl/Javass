package ch.epfl.javass.jass;

import java.util.StringJoiner;

import ch.epfl.javass.bits.Bits32;
import ch.epfl.javass.bits.Bits64;
import ch.epfl.javass.jass.Card.Color;
import ch.epfl.javass.jass.Card.Rank;

/**
 * @author Mathis Randl
 *
 */
public final class PackedCardSet {
    private PackedCardSet() {
    }

    public static final long EMPTY = 0L;
    public static final long ALL_CARDS = 0x01FF_01FF_01FF_01FFL;
    // 01FF == 0b0000000111111111, hexadecimal provides a compact form
    // for this particular set. "_" added for clarity

    /*
     * Next method is computationally heavy but used only once, one could also have
     * used a hardcode directly for the array but i was told it was ugly. So
     * here we go
     */
    /**
     * @return the array that dictates what cards are better than another when
     *         they both are of the trump color
     */
    private final static long[][] generateTrumpAboveArray() {
        long[][] tmp = new long[4][9];
        // could have gone with only a [9] array and bitshift it as needed in
        // trumpAbove(), but this produces less computations if 
        // that method is heavily used
        long iterator;
        for (int color = 0; color < 4; ++color) {
            for (int rank = 0; rank < 9; ++rank) {
                iterator = 0;
                // every card that is comparable gets compared to the card of
                // color color and rank rank
                // result is stored in iterator then saved in tmp[color][rank]
                for (int comparedRank = 0; comparedRank < 9; ++comparedRank) {
                    iterator |= ((Card.Rank.ALL.get(comparedRank).trumpOrdinal() > 
                                  Card.Rank.ALL.get(rank).trumpOrdinal() ? 1L : 0L)
                                  << (16 * color) + comparedRank);
                }
                tmp[color][rank] = iterator;
            }
        }
        return tmp;
    }

    // We can now store the result
    private final static long[][] trumpAboveArray = generateTrumpAboveArray();

    // Uses a hardcode on purpose because a generateSubsetOfColorArray()
    // method is as long in number of lines, but less clear
    private final static long[] subsetOfColorArray = new long[] { 
            0x01FFL,
            0x01FFL << 16,
            0x01FFL << 32, 
            0x01FFL << 48 // See line 20-21 for an
                          // explanation of the
                          // value 0x01FFL
    };

    /**
     * @param pkCardSet
     *            a packed set of cards
     * @return true if the card set does not contain illegal cards, false else
     */
    public static boolean isValid(long pkCardSet) {
        return ((~ALL_CARDS & pkCardSet) == 0);
    }

    /**
     * @param pkCard
     *            a packed card
     * @return the packed set of cards that contains all the cards superior to
     *         pkCard, knowing its color is trump
     */
    public static long trumpAbove(int pkCard) {
        assert (PackedCard.isValid(pkCard));
        return trumpAboveArray[Bits32.extract(pkCard, 4, 2)]
                              [Bits32.extract(pkCard, 0, 4)];
    }

    /**
     * @param pkCard
     *            a packed card
     * @return the packed set of cards that only contains pkCard
     * @throws IllegalArgumenException
     *             if pkCard is not valid card
     */
    public static long singleton(int pkCard) {
        assert (PackedCard.isValid(pkCard));
        return Bits64.mask(Bits32.extract(pkCard, 0, 4)
                + Bits32.extract(pkCard, 4, 2) * 16, 1);
    }

    /**
     * @param pkCardSet
     *            a packed card set
     * @return true if the set is empty, false else
     * @throws IllegalArgumentException
     *             if pkCardSet is invalid
     */
    public static boolean isEmpty(long pkCardSet) {
        assert (isValid(pkCardSet));
        return pkCardSet == 0;
    }

    /**
     * @param pkCardSet
     *            a packed card set
     * @return the number of cards in it
     * @throws IllegalArgumentException
     *             if pkCardSet is invalid
     */
    public static int size(long pkCardSet) {
        assert (isValid(pkCardSet));
        return Long.bitCount(pkCardSet);
    }

    /**
     * @param pkCardSet
     *            a packed card set
     * @param index
     *            an integer between 0 included and size(pkCardSet) excluded
     * @return the packed card in pkCardSet of the index-th "1" bit
     */
    public static int get(long pkCardSet, int index) {
        assert (isValid(pkCardSet) && size(pkCardSet) > index);

        int finalCardActualIndex = 0;
        for (int i = 0; i <= index; ++i) {

            finalCardActualIndex += Long.numberOfTrailingZeros(pkCardSet) + 1;
            pkCardSet >>= Long.numberOfTrailingZeros(pkCardSet) + 1;
            // removes all trailing 0's and one 1, index times,
            // and counts how much was deleted
        }
        return PackedCard.pack(Color.ALL.get(finalCardActualIndex / 16),
                Rank.ALL.get((finalCardActualIndex - 1) % 16));
        // returns the packed card with color index ranging from 0 to 3,
        // and rank ranging from 0 to 15 but only uses from 0 to 8
    }

    /**
     * @param pkCardSet
     *            a packed card set
     * @param pkCard
     *            a packed card
     * @return the packed card set that contains all of pkCardSet and pkCard
     * @throws IllegalArgumentException
     *             if the set or the card is invalid
     */
    public static long add(long pkCardSet, int pkCard) {
        assert (isValid(pkCardSet));
        return pkCardSet | singleton(pkCard);
    }

    /**
     * @param pkCardSet
     *            a packed card set
     * @param pkCard
     *            a packed card
     * @return the packed card set that contains all of pkCardSet without pkCard
     * @throws IllegalArgumentException
     *             if the set or the card is invalid
     */
    public static long remove(long pkCardSet, int pkCard) {
        assert (isValid(pkCardSet));
        return pkCardSet & ~singleton(pkCard);
    }

    /**
     * @param pkCardSet
     *            a packed card set
     * @param card
     *            a card
     * @return true if card is in the set, false in all other cases
     */
    public static boolean contains(long pkCardSet, int pkCard) {
        assert (isValid(pkCardSet));
        return (pkCardSet & singleton(pkCard)) != 0;
    }

    /**
     * @param pkCardSet
     * @return the opposite set of pkCardSet
     */
    public static long complement(long pkCardSet) {
        assert (isValid(pkCardSet));
        return ~pkCardSet & ALL_CARDS;
    }

    /**
     * @param pkCardSet1
     *            a packed set of cards
     * @param pkCardSet2
     *            another packed set of cards
     * @return the union of both sets
     */
    public static long union(long pkCardSet1, long pkCardSet2) {
        assert (isValid(pkCardSet1) && isValid(pkCardSet1));
        return pkCardSet1 | pkCardSet2;
    }

    /**
     * @param pkCardSet1
     *            a packed set of cards
     * @param pkCardSet2
     *            another packed set of cards
     * @return the intersection of both sets
     */
    public static long intersection(long pkCardSet1, long pkCardSet2) {
        assert (isValid(pkCardSet1) && isValid(pkCardSet1));
        return pkCardSet1 & pkCardSet2;
    }

    /**
     * @param pkCardSet1
     *            a packed set of cards
     * @param pkCardSet2
     *            another packed set of cards
     * @return the difference of both sets
     */
    public static long difference(long pkCardSet1, long pkCardSet2) {
        assert (isValid(pkCardSet1) && isValid(pkCardSet1));
        return intersection(pkCardSet1, complement(pkCardSet2));
    }

    /**
     * @param pkCardSet
     *            a packed set of cards
     * @param color
     *            a color
     * @return the packed set of cards that only contains cards that are of
     *         color color and are in the set
     */
    public static long subsetOfColor(long pkCardSet, Card.Color color) {
        return pkCardSet & subsetOfColorArray[Card.Color.ALL.indexOf(color)];
        // since the array is private static it will be pre-generated 
        // and thus avoids us runtime computations
    }

    public static String toString(long pkCardSet) {
        assert (isValid(pkCardSet));
        StringJoiner j = new StringJoiner(",", "{", "}");
        for (int i = 0; i < size(pkCardSet); ++i) {
            j.add(PackedCard.toString(get(pkCardSet, i)));
        }
        return j.toString();
    }
}
