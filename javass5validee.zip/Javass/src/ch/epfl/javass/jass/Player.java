package ch.epfl.javass.jass;

import java.util.Map;

import ch.epfl.javass.jass.Card.Color;

public interface Player {
    public abstract Card cardToPlay(TurnState state, CardSet hand);
    
    
    
    public default void setPlayers(PlayerId ownId, Map<PlayerId, String> playerNames) {}
    
    public default void updateHand(CardSet newHand) {}
    
    public default void setTrump(Color trump) {}   
    
    
    
    public default void updateTrick(Trick newTrick) {}
    
    public default void updateScore(Score score) {}
    
    public default void setWinningTeam(TeamId winningTeam) {}
    
}
