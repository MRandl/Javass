package ch.epfl.javass.gui;

import ch.epfl.javass.jass.Card;
import ch.epfl.javass.jass.PlayerId;
import ch.epfl.javass.jass.TeamId;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.MapChangeListener;
import javafx.collections.ObservableMap;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;

public class GraphicalPlayer {

    private static final ObservableMap<Card, Image> cardToImage = generateCardToImage();
    private static final ObservableMap<Card.Color, Image> trumpToImage = generateTrumpToImage();
    private Scene scene;



    public GraphicalPlayer(PlayerId p, Map<PlayerId, String> nameMap, ScoreBean sB, TrickBean tB, double scale){
        VBox v = new VBox();
        v.getChildren().addAll(createScorePane(sB, nameMap, scale), createTrickPane(p, nameMap, tB, scale));
        this.scene = new Scene(v);
    }

    public Stage createStage(){
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Javass");
        stage.setResizable(false);
        return stage;
    }

    private static ObservableMap<Card, Image> generateCardToImage() {
        Map<Card, Image> finalMap = new HashMap<>();
        for(short i = 0; i < 4; ++i)
            for(short j = 0; j < 9; ++j)
                finalMap.put(Card.of(Card.Color.ALL.get(i), Card.Rank.ALL.get(j)),
                        new Image("/card_"+i+"_"+j+"_240.png"));
        return FXCollections.observableMap(finalMap);
    }

    private static ObservableMap<Card.Color, Image> generateTrumpToImage() {
        Map<Card.Color, Image> finalMap = new HashMap<>();
        for(short i = 0; i < 4; ++i)
            finalMap.put(Card.Color.ALL.get(i), new Image("/trump_" + i + ".png"));
        return FXCollections.observableMap(finalMap);
    }

    private static GridPane createScorePane(ScoreBean sB, Map<PlayerId, String> map, double scale){

        GridPane grid = new GridPane();
        grid.setStyle("-fx-font: " + (int)(10 * scale) +
                " Optima; -fx-background-color: #d3d3d3;" +
                " fx-padding: 5px; -fx-alignment: center;");

        for(TeamId team : TeamId.ALL) {

            grid.add(new Label(map.get(PlayerId.ALL.get(team.ordinal())) + " et "
                + map.get(PlayerId.ALL.get(team.ordinal() + 2)) + " :"), 0, team.ordinal());

            Text turnPoints = new Text();
            turnPoints.textProperty().bind(Bindings.convert(sB.turnPointsProperty(team)));
            grid.add(turnPoints, 1, team.ordinal());

            Text trickPoints = new Text("(+0) ");
            sB.turnPointsProperty(team).addListener(
                    (o, oV, nV) -> trickPoints.setText("(+" + (nV.intValue() - oV.intValue()) + ")"));
            grid.add(trickPoints, 2, team.ordinal());

            grid.add(new Label("/Total :"), 3, team.ordinal());

            Text totalPoints = new Text();
            totalPoints.textProperty().bind(Bindings.convert(sB.totalPointsProperty(team)));
            grid.add(totalPoints, 4, team.ordinal());
        }
        return grid;
    }

    private static GridPane createTrickPane(PlayerId currentPlayer,
                            Map<PlayerId, String> nameMap, TrickBean tb, double scale){

        GridPane grid = new GridPane();
        grid.setStyle("-fx-background-color: whitesmoke; -fx-padding: 5px;" +
                " -fx-border-width: 3px 0px; -fx-border-style: solid;" +
                " -fx-border-color: gray; -fx-alignment: center;");

        short[] xCoordinates = new short[]{1,0,1,3};
        short[] yCoordinates = new short[]{2,0,0,0};
        short[] cellYSize =    new short[]{1,3,1,3};
        //the arrays describe where the different cards will be placed (xCoordinates and yCoordinates)
        //and their respective vertical size (cellYSize) in number of cells. Note that card #0 is the current player's one,
        //therefore the centered-bottom one, card #1 is the next player's, at the left of the screen, etc etc

        for(PlayerId playerId : PlayerId.ALL) {

            VBox v = new VBox();
            v.setAlignment(Pos.CENTER);

            Text playerP = new Text();
            playerP.setText(nameMap.get(playerId));
            playerP.setFont(Font.font("Optima", (int)(10 * scale)));
            //no need for a property as the name/font of a player does not evolve with time

            StackPane stack = new StackPane();
            Rectangle rectangle = new Rectangle();
            rectangle.setHeight(90 * scale);
            rectangle.setWidth(60*scale);
            rectangle.setStyle("-fx-arc-width: 20; -fx-arc-height: 20; -fx-fill: transparent; " +
                    "-fx-stroke: lightpink; -fx-stroke-width: 5; -fx-opacity: 0.5;");
            rectangle.setEffect(new GaussianBlur(4));
            rectangle.visibleProperty().bind(tb.getWinningPlayer().isEqualTo(playerId));

            ImageView iv = new ImageView();
            tb.getTrick().addListener((MapChangeListener<PlayerId, Card>) mapChange ->
                    iv.setImage(cardToImage.get(mapChange.getMap().get(playerId))));
            iv.setFitHeight(90 * scale);
            iv.setFitWidth(60 * scale);

            stack.getChildren().addAll(rectangle, iv);

            if(playerId == currentPlayer) {
                v.getChildren().addAll(stack, playerP);
            }else {
                v.getChildren().addAll(playerP, stack);
            }

            short relativePlayerOrdinal = (short) ((playerId.ordinal() + (4 - currentPlayer.ordinal()))%4);
            //+(4 - x) is the same as -x when mod 4, but 4-x is positive
            // and thus makes sure the %4 operator behaves as planned
            grid.add(v,
                    xCoordinates[relativePlayerOrdinal],
                    yCoordinates[relativePlayerOrdinal],
                    1,
                    cellYSize[relativePlayerOrdinal]
                    );
        }

        ImageView iv = new ImageView();
        iv.setFitHeight(50*scale);
        iv.setFitWidth(50*scale);
        tb.getTrump().addListener((o, oV, nV) -> iv.setImage(trumpToImage.get(nV)));
        grid.add(iv, 1, 1);
        GridPane.setHalignment(iv, HPos.CENTER);

        return grid;
    }
}
