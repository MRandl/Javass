package ch.epfl.javass.net;

import ch.epfl.javass.jass.*;

import java.io.*;
import java.net.Socket;
import java.util.Map;

import static ch.epfl.javass.net.StringSerializer.deserializeInt;
import static ch.epfl.javass.net.StringSerializer.serializeInt;
import static ch.epfl.javass.net.StringSerializer.serializeLong;
import static ch.epfl.javass.net.StringSerializer.theJoiner;

import static java.nio.charset.StandardCharsets.US_ASCII;

public final class RemotePlayerClient implements Player, AutoCloseable {

    private BufferedReader r;
    private BufferedWriter w;
    private Socket s;

    public RemotePlayerClient(String name){

        try {s = new Socket(name, 5108);
             r = new BufferedReader(
                             new InputStreamReader(s.getInputStream(),
                                     US_ASCII));
             w = new BufferedWriter(
                             new OutputStreamWriter(s.getOutputStream(),
                                     US_ASCII));}
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public Card cardToPlay(TurnState state, CardSet hand) {
        try {
            String toBeSent = "CARD " + theJoiner(',', serializeLong(state.packedScore()),
                    serializeLong(state.packedUnplayedCards()),
                    serializeInt(state.packedTrick()))
                    + " " + serializeLong(hand.packed());
            w.write(toBeSent);
            w.write('\n');
            w.flush();
            String s = r.readLine();
            return Card.ofPacked(deserializeInt(s));
        } catch (IOException e) {
            e.printStackTrace();
            throw new IllegalArgumentException();
        }
    }

    @Override
    public void setPlayers(PlayerId ownId, Map<PlayerId, String> playerNames) {
        try{
            String[] playerPlainText = new String[4];
            for(int i = 0; i < 4; ++i)
                playerPlainText[i] = StringSerializer.serializeString(playerNames.get(PlayerId.ALL.get(i)));
            String toBeSent = "PLRS " + ownId.ordinal() + " " + theJoiner(',', playerPlainText);
            w.write(toBeSent);
            w.write('\n');
            w.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateHand(CardSet newHand) {
        try{
            w.write("HAND " + StringSerializer.serializeLong(newHand.packed()));
            w.write('\n');
            w.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void setTrump(Card.Color trump) {
        try{
            w.write("TRMP " + trump.ordinal());
            w.write('\n');
            w.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateTrick(Trick newTrick) {
        try{
            w.write("TRCK " + StringSerializer.serializeInt(newTrick.packed()));
            w.write('\n');
            w.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateScore(Score score) {
        try{
            w.write("SCOR " + StringSerializer.serializeLong(score.packed()));
            w.write('\n');
            w.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void setWinningTeam(TeamId winningTeam) {
        try{
            w.write("WINR " + winningTeam.ordinal());
            w.write('\n');
            w.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void close() throws Exception {
        w.close();
        r.close();
        s.close();
    }
}
