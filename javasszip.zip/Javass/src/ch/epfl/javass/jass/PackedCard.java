package ch.epfl.javass.jass;


import ch.epfl.javass.bits.Bits32;
import ch.epfl.javass.jass.Card.Color;
import static ch.epfl.javass.Preconditions.checkArgument;

/**
 * @author Mathis Randl
 *
 */
public final class PackedCard {
    
    private PackedCard() {}
    public static int INVALID = 111111;
    
    /**
     * @param pkCard a packed card
     * @return true if pkCard is a valid card, false if it is not
     */
    public static boolean isValid(int pkCard) {
        return Bits32.extract(pkCard,0,4) <= 0b1000 && pkCard >>> 6 == 0;
    }
    
    /**
     * @param c a color
     * @param r a rank
     * @return the packed card that corresponds to the color c and rank r
     */
    public static int pack(Card.Color c, Card.Rank r) {
        return  Bits32.pack(Card.Rank.ALL.indexOf(r), 4, Card.Color.ALL.indexOf(c), 2);
    }
    
    /**
     * @param pkCard a packed card
     * @return the color of pkCard
     * @throws IllegalArgumentException() if the card is invalid
     */
    public static Card.Color color (int pkCard){
        checkArgument(isValid(pkCard));
        return Card.Color.ALL.get(Bits32.extract(pkCard,4,2));
    }
    
    /**
     * @param pkCard a packed card
     * @return the rank of pkCard
     * @throws IllegalArgumentException() if the card is invalid
     */
    public static Card.Rank rank(int pkCard){
        checkArgument(isValid(pkCard));
        return Card.Rank.ALL.get(Bits32.extract(pkCard,0,4));
    }
    
    /**
     * @param trump the trump in that current round
     * @param pkCardL a packed card
     * @param pkCardR another packed card
     * @return true if pkCardL is comparable to pkCard R and is a better card, false else
     * @throws IllegalArgumentException if at least one of the cards is not valid
     */
    public static boolean isBetter(Card.Color trump,int pkCardL, int pkCardR) {
        checkArgument(isValid(pkCardL) && isValid(pkCardR));
        
        if(color(pkCardL) != color(pkCardR)) 
            return color(pkCardL) == trump ? true : false;
        
        if(trump == color(pkCardL)) 
            return rank(pkCardL).trumpOrdinal() > rank(pkCardR).trumpOrdinal();
        else 
            return Card.Rank.ALL.indexOf(rank(pkCardL)) > Card.Rank.ALL.indexOf(rank(pkCardR));
        
    
    }

    /**
     * @param trump the trump in that current round
     * @param pack a packed card
     * @return the points that card is worth
     * @throws IllegalArgumentException() if the card is invalid
     */
    public static int points(Color trump, int pack) {
        checkArgument(isValid(pack));
        int valueNotTrump[] = new int[] {0,0,0,0,10,2,3,4,11};
        int valueTrump[] = new int[] {0,0,0,14,10,20,3,4,11};
        return color(pack) == trump ? valueTrump[Card.Rank.ALL.indexOf(rank(pack))] : valueNotTrump[Card.Rank.ALL.indexOf(rank(pack))];
    }
    
    public static String toString(int pkCard) {
        // no need to check arguments there
        return "" + rank(pkCard).toString() + color(pkCard).toString(); 
    }
}
