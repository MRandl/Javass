package ch.epfl.javass.jass;

/**
 * @author Mathis Randl
 *
 */
public class Main {
// /!\ IRRELEVANT TESTING CLASS /!\
    public static void main(String[] args) {
        System.out.println(PackedCardSet.toString(PackedCardSet.ALL_CARDS));
        long s = PackedCardSet.EMPTY;
        int c1 = PackedCard.pack(Card.Color.HEART, Card.Rank.SIX);
        int c2 = PackedCard.pack(Card.Color.SPADE, Card.Rank.ACE);
        int c3 = PackedCard.pack(Card.Color.SPADE, Card.Rank.SIX);
        s = PackedCardSet.add(s, c1);
        s = PackedCardSet.add(s, c2);
        s = PackedCardSet.add(s, c3);
        System.out.println(PackedCardSet.toString(s));
    }

}
