package ch.epfl.javass.jass;

/**
 * @author Mathis Randl
 *
 */
public class Main {
// /!\ IRRELEVANT DEBUGGING CLASS /!\
    public static void main(String[] args) {
        
    }
}
