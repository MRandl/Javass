package ch.epfl.javass.jass;

import ch.epfl.javass.Preconditions;
import ch.epfl.javass.jass.Card.Color;

public final class Trick {
    private Trick(int pk) {
        this.pkTrick = pk;
    }
    
    private int pkTrick;
    
    public final static Trick INVALID = new Trick(PackedTrick.INVALID);
    
    public static Trick firstEmpty(Color trump, PlayerId firstPlayer) {
        return ofPacked(PackedTrick.firstEmpty(trump, firstPlayer));
    }

    public static Trick ofPacked(int pkValue) {
        Preconditions.checkArgument(PackedTrick.isValid(pkValue));
        return new Trick(pkValue);
    }
    
    public int packed() {
        return pkTrick;
    }
    
    public Trick nextEmpty() {
        Preconditions.checkArgument(size() == 4);
        return ofPacked(PackedTrick.nextEmpty(pkTrick));
    }

    public int size() {
        return PackedTrick.size(pkTrick);
    }
    
    public boolean isEmpty() {
        return PackedTrick.isEmpty(pkTrick);
    }
    
    public boolean isFull() {
        return PackedTrick.isFull(pkTrick);
    }
    
    public boolean isLast() {
        return PackedTrick.isLast(pkTrick);
    }
    
    public Color trump() {
        return PackedTrick.trump(pkTrick);
    }
    
    public int index() {
        return PackedTrick.index(pkTrick);
    }
    
    public PlayerId player(int index) {
        Preconditions.checkArgument(0 <= index && index < 4);
        return PackedTrick.player(pkTrick, index);
    }
    
    public Card card(int index) {
        Preconditions.checkArgument(size() > index);
        return Card.ofPacked(PackedTrick.card(pkTrick, index));
    }
    
    public Trick withAddedCard(Card c) {
        Preconditions.checkArgument(!isFull());
        return ofPacked(PackedTrick.withAddedCard(pkTrick, PackedCard.pack(c.color(), c.rank())));
    }
    
    public Color baseColor() {
        if(isEmpty())
            throw new IllegalStateException();
        return PackedTrick.baseColor(pkTrick);
    }
    
    public CardSet playableCards(CardSet hand) {
        if(isFull())
            throw new IllegalStateException();
        return CardSet.ofPacked(PackedTrick.playableCards(pkTrick, hand.packed()));
    }
    
    public int points() {
        return PackedTrick.points(pkTrick);
    }
    
    public PlayerId winningPlayer() {
        if(isEmpty())
            throw new IllegalStateException();
        return PackedTrick.winningPlayer(pkTrick);
    }
    
   @Override
   public boolean equals(Object o) {
       if(o instanceof Trick) {
           return packed() == ((Trick) o).packed();
       }
       return false;
   }
   
   @Override 
   public int hashCode() {
       return packed();
   }
   
   @Override
   public String toString() {
       return "Not implemented lol";
   }

}
