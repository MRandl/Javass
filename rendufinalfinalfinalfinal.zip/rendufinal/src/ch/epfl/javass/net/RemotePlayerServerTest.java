package ch.epfl.javass.net;

import ch.epfl.javass.jass.PrintingPlayer;
import ch.epfl.javass.jass.RandomPlayer;

/**
 * @author Mathis Randl (303140)
 * @author Aya Rahmoun (288078)
 */

class RemotePlayerServerTest
{
    public static void main(String[] arguments){
        RemotePlayerServer rs = new RemotePlayerServer(new PrintingPlayer(new RandomPlayer(65)));
        rs.run();
    }


}