package ch.epfl.javass.gui;

import ch.epfl.javass.jass.TeamId;
import javafx.beans.property.*;


/**
 * @author Mathis Randl (303140)
 * @author Aya Rahmoun (288078)
 */

public final class ScoreBean {
    private SimpleIntegerProperty
            turnPoints1 = new SimpleIntegerProperty(),
            gamePoints1 = new SimpleIntegerProperty(),
            totalPoints1 = new SimpleIntegerProperty(),
            turnPoints2 = new SimpleIntegerProperty(),
            gamePoints2 = new SimpleIntegerProperty(),
            totalPoints2 = new SimpleIntegerProperty();
    private SimpleObjectProperty<TeamId> winningTeam = new SimpleObjectProperty<>();

    /**
     * @param team a team
     * @return the turn points of the team team
     */
    ReadOnlyIntegerProperty turnPointsProperty(TeamId team){
        return team == TeamId.TEAM_1 ? IntegerProperty.readOnlyIntegerProperty(turnPoints1) : IntegerProperty.readOnlyIntegerProperty(turnPoints2);
    }

    /**
     * @param team a team
     * @param newTurnPoints the new turn points
     */
    void setTurnPoints(TeamId team, int newTurnPoints){
        if (team == TeamId.TEAM_1) turnPoints1.set(newTurnPoints);
        else turnPoints2.set(newTurnPoints);
    }

    /**
     * @param team a team
     * @return the game points of the team team
     */
    ReadOnlyIntegerProperty gamePointsProperty(TeamId team){
        return team == TeamId.TEAM_1 ? IntegerProperty.readOnlyIntegerProperty(gamePoints1) : IntegerProperty.readOnlyIntegerProperty(gamePoints2);
    }

    /**
     * @param team a team
     * @param newGamePoints the new game points of the team team
     */
    void setGamePoints(TeamId team, int newGamePoints){
        if (team == TeamId.TEAM_1) gamePoints1.set(newGamePoints);
        else gamePoints2.set(newGamePoints);
    }

    /**
     * @param team a team
     * @return the total points of the team team
     */
    ReadOnlyIntegerProperty totalPointsProperty(TeamId team){
        return team == TeamId.TEAM_1 ? IntegerProperty.readOnlyIntegerProperty(totalPoints1) : IntegerProperty.readOnlyIntegerProperty(totalPoints2);
    }

    /**
     * @param team a team
     * @param newTotalPoints the new total points of the team
     */
    void setTotalPoints(TeamId team, int newTotalPoints){
        if (team == TeamId.TEAM_1) totalPoints1.set(newTotalPoints);
        else totalPoints2.set(newTotalPoints);
    }

    /**
     * @return the winning team
     */
    ReadOnlyObjectProperty<TeamId> winningTeamProperty(){
        return winningTeam;
    }

    /**
     * @param t the team that won
     */
    void setWinningTeam(TeamId team){
        winningTeam.set(team);
    }
}
