package ch.epfl.javass;

/**
 * Conditions requises sinon une exception est levée
 * 
 * @author Mathis Randl (303140)
 * @author Aya Rahmoun (288078)
 *
 */

public final class Preconditions {
    
    private Preconditions() {
    }

    /**
     * Check si la condition recu en paramètre est validée ou non
     *
     * @param b un boolean
     * @throws IllegalArgumentException si le boolean est false
     */
    public static void checkArgument(boolean b) {
        if (!b)
            throw new IllegalArgumentException();
    }

    /**
     * Check si lindex est entre 0 compris et size non compris
     *
     * @param index un int
     * @param size un entier
     * @throws IndexOutOfBoundsException si index est plus petit aue 0 ou plus grand ou égal à size
     * @return index
     */
    public static int checkIndex(int index, int size) {
        if (index < 0 || index >= size)
            throw new IndexOutOfBoundsException();
        return index;
    }
}