// Javass stage 1

package ch.epfl.test;

import java.util.SplittableRandom;

/**
 * @author Mathis Randl (303140)
 * @author Aya Rahmoun (288078)
 */

public final class TestRandomizer {
    // Fix random seed to guarantee reproducibility.
    public final static long SEED = 2019;

    public final static int RANDOM_ITERATIONS = 100;

    public static SplittableRandom newRandom() {
        return new SplittableRandom(SEED);
    }
}
