package ch.epfl.javass.jass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import ch.epfl.javass.jass.Card.Color;
import ch.epfl.javass.jass.Card.Rank;

public final class JassGame {
    public JassGame(long rngSeed, Map<PlayerId, Player> players, Map<PlayerId, String> playerNames) {
        Random rng = new Random(rngSeed);
        this.shuffleRng = new Random(rng.nextLong());
        this.trumpRng = new Random(rng.nextLong());
        
       
    }
    
    
    private boolean isNewGame = true;
    private Score score;
    private int[] cards = new int[4];
    private Random shuffleRng;
    private Random trumpRng;
    private TurnState turnstate;
    private Color finaltrump;
    
    boolean isGameOver() {
        return score.totalPoints(TeamId.TEAM_1) >= Jass.WINNING_POINTS || 
               score.totalPoints(TeamId.TEAM_2) >= Jass.WINNING_POINTS;
    }
    
    private void newTurn(Color trump, PlayerId firstPlayer){
        this.turnstate = TurnState.initial(trump, this.score, firstPlayer);
    }
    
    
    
    private List<Card> deckShuffler() {
        List<Card> deck = new ArrayList<>();
        for(int color = 0; color < 9; ++color)
            for(int rank = 0; rank < 3; ++ rank)
                deck.add(Card.of(Color.ALL.get(color), Rank.ALL.get(rank)));
        Collections.shuffle(deck, shuffleRng);
        for(short i = 0; i < 4; ++i)
            cards[i] = (int) CardSet.of(deck.subList(i*9,(i+1)*9 -1)).packed();
        
        return deck;
    }
    
    private Color trumpShuffle() {
        return this.finaltrump = Color.ALL.get(trumpRng.nextInt(4));
    }
    
    private void setupGame() {
        this.score = Score.INITIAL;
        for(short i = 0; i < 4; ++i) {
            
        }
        this.turnstate = TurnState.initial(trumpShuffle(), score, null);/////////////////////////////////////////////
    }
    
    private void updateTrick() {}
    
    private void generateNewTurnSet() {}
    
    private void displayToPlayers() {}
    
    private void playersPlay() {}
      
    public void advanceToEndOfNextTrick() {
        if(isGameOver()) return;
        
        if(isNewGame) {
            isNewGame = false;
            setupGame();
            
        } else {
            updateTrick();
        }
        
        if(turnstate.isTerminal()) {
            generateNewTurnSet();
        }
        
        displayToPlayers();
        
        if(isGameOver()) return;
        
        playersPlay();

        
    }

}
