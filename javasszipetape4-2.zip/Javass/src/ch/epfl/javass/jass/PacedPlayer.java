package ch.epfl.javass.jass;

public final class PacedPlayer implements Player {
    
    private Player underLy;
    private double minTime;

    public PacedPlayer(Player underlyingPlayer, double minTime) {
        this.underLy = underlyingPlayer;
        this.minTime = minTime;
    }
    
    @Override
    public Card cardToPlay(TurnState state, CardSet hand) {
        long begin = System.currentTimeMillis();
        Card result = underLy.cardToPlay(state, hand);
        long end = System.currentTimeMillis();
        if(end-begin < minTime) {
            try {
                Thread.sleep((long) (minTime - (end - begin)));
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return result;
    }
    
}
