package ch.epfl.javass.jass;

import static ch.epfl.javass.bits.Bits64.*;

/**
 * @author Mathis Randl
 *
 */
public final class PackedScore {
    private PackedScore() {
    }

    public static final long INITIAL = 0;

    /**
     * @param pkScore
     *            a packed score
     * @return true if the packed score only contains legal values, false else
     */
    public static boolean isValid(long pkScore) {
        boolean assertion = true;

        assertion = assertion && (extract(pkScore, 0, 4) <= 9)
                && (extract(pkScore, 4, 9) <= 257)
                && (extract(pkScore, 13, 11) <= 2000)
                && (extract(pkScore, 24, 8) == 0);

        pkScore >>>= 32;

        assertion = assertion && (extract(pkScore, 0, 4) <= 9)
                && (extract(pkScore, 4, 9) <= 257)
                && (extract(pkScore, 13, 11) <= 2000)
                && (extract(pkScore, 24, 8) == 0);

        return assertion;
    }

    /**
     * @param turnTricks1
     *            the number of tricks won by team 1
     * @param turnPoints1
     *            the number of points won by team 1 during the turn
     * @param gamePoints1
     *            the number of points won by team 1 before the turn
     * @param turnTricks2
     *            the number of tricks won by team 2
     * @param turnPoints2
     *            the number of points won by team 2 during the turn
     * @param gamePoints2
     *            the number of points won by team 2 before the turn
     * @return the score that packs all of them
     * @throws AssertionError
     *             if arguments are somehow invalid
     */
    public static long pack(int turnTricks1, int turnPoints1, int gamePoints1,
            int turnTricks2, int turnPoints2, int gamePoints2) {

        int[] values = new int[] { turnTricks1, turnPoints1, gamePoints1,
                turnTricks2, turnPoints2, gamePoints2 };

        int[] bitshift = new int[] { 0, 4, 13, 32, 36, 45 };

        long finalResult = 0;

        for (int i = 0; i <= 5; ++i) {
            finalResult |= ((long) values[i] << bitshift[i]);
        }

        assert isValid(finalResult);
        return finalResult;
    }

    /**
     * @param pkScore
     *            a packed score
     * @param t
     *            a team
     * @return the number of tricks won by that team, according to that score
     */
    public static int turnTricks(long pkScore, TeamId t) {
        assert isValid(pkScore);
        return (int) extract(pkScore, (t == TeamId.TEAM_1 ? 0 : 32), 4);
    }

    /**
     * @param pkScore
     *            a packed score
     * @param t
     *            a team
     * @return the number of points won by that team in the current turn,
     *         according to that score
     */
    public static int turnPoints(long pkScore, TeamId t) {
        assert isValid(pkScore);
        return (int) extract(pkScore, t == TeamId.TEAM_1 ? 4 : 36, 9);
    }

    /**
     * @param pkScore
     *            a packed score
     * @param t
     *            a team
     * @return the number of points won by that team in the previous turns,
     *         according to that score
     */
    public static int gamePoints(long pkScore, TeamId t) {
        assert isValid(pkScore);
        return (int) extract(pkScore, t == TeamId.TEAM_1 ? 13 : 45, 11);
    }

    /**
     * @param pkScore
     *            a packed score
     * @param t
     *            a team
     * @return the total number of points earned by that team during the whole
     *         game
     */
    public static int totalPoints(long pkScore, TeamId t) {
        // no need for an assert here
        return gamePoints(pkScore, t) + turnPoints(pkScore, t);
    }

    /**
     * @param pkScore
     *            a packed score
     * @param winningTeam
     *            a team
     * @param trickPoints
     *            a number of points
     * @return the updated packed score
     * @throws AssertionError
     *             if the arguments are somehow incorrect
     */
    public static long withAdditionalTrick(long pkScore, TeamId winningTeam,
            int trickPoints) {

        pkScore += ((winningTeam == TeamId.TEAM_1) ? 1 : (long) 1 << 32);
            // adds a won trick to the winning team

        if (turnTricks(pkScore, winningTeam) == 9)
            trickPoints += Jass.MATCH_ADDITIONAL_POINTS;
            // adds 100 points for an all win situation

        pkScore += (winningTeam == TeamId.TEAM_1 ? trickPoints << 4
                : (long) trickPoints << 36);
                // adds the trick points
        
        assert isValid(pkScore);
            // makes sure the arguments were valid
        return pkScore;
    }

    /**
     * @param pkScore
     *            a packed score
     * @return a packed score that is empty except for the total points won by
     *         the teams
     */
    public static long nextTurn(long pkScore) {
        // no need to check there
        return pack(0, 0, totalPoints(pkScore, TeamId.TEAM_1), 0, 0,
                totalPoints(pkScore, TeamId.TEAM_2));
    }

    public static String toString(long pkScore) {
        // no need to check there
        return "(" + turnTricks(pkScore, TeamId.TEAM_1) + ","
                + turnPoints(pkScore, TeamId.TEAM_1) + ","
                + gamePoints(pkScore, TeamId.TEAM_1) + ")/("
                + turnTricks(pkScore, TeamId.TEAM_2) + ","
                + turnPoints(pkScore, TeamId.TEAM_2) + ","
                + gamePoints(pkScore, TeamId.TEAM_2) + ")";
    }
}
