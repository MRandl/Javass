package ch.epfl.javass.jass;

import java.util.List;
import java.util.SplittableRandom;

public class MctsPlayer implements Player {

    public MctsPlayer(PlayerId ownId, long rngSeed, int iterations) {
        if(iterations < 9) throw new IllegalArgumentException(); 
        ownName = ownId;
        rng = new SplittableRandom(rngSeed);
        
        this.iterations = iterations;
    }
    
    private PlayerId ownName;
    private SplittableRandom rng;
    private int iterations;
    
    
    
    
    private static class Node{
        private Node daddy;
        private TurnState ts;
        private Node[] children;
        private int bigS = 0;
        private int bigN = 0;
        private int numberOfChildren = 0;
        private PlayerId player;
        
        private Node(TurnState ts, PlayerId player, Node dad) {
            this.ts = ts;
            this.player = player;
            this.children = new Node[ts.unplayedCards().size()];
            this.daddy = dad;
        }
        
        private static void addASon(Node n) {
            if(n.numberOfChildren >= n.ts.unplayedCards().size()) 
                throw new IllegalStateException();
            if(n.ts.unplayedCards().size() == 0)
                throw new NullPointerException();
            
            
            PlayerId playerToPlay;
            try {
                playerToPlay = n.ts.nextPlayer();
            } catch(IllegalStateException e) {
                playerToPlay = n.ts.withTrickCollected().nextPlayer();
            }
            Node k = new Node(n.ts.withNewCardPlayedAndTrickCollected(n.ts.unplayedCards().get(0)), playerToPlay, n);
            n.children[n.numberOfChildren] = k;
            ++n.numberOfChildren;
            
        }
        
        private int selectBestSon() {
            if(numberOfChildren == 0) 
                throw new IllegalArgumentException();
            int indexOfBest = 0;
            for(int i = 0; i < numberOfChildren; ++i)
                if(children[indexOfBest].value() < children[i].value())
                    indexOfBest = i;
            return indexOfBest;
        }
        
        private static void addADescendant(Node n) {
            Node actualFather = n;
            while(true) {
            try{
                    addASon(actualFather);
            } catch(IllegalStateException e) {
                actualFather = actualFather.children[actualFather.selectBestSon()];
                continue;
            } catch(NullPointerException e) {
                return;
            } 
                break;
        }
        }
        
        
        
        private double value(double c) {
            if(bigN ==  0)
                return Double.MAX_VALUE;
            return ((double)bigS/(double)bigN) + c * Math.sqrt((2*Math.log(daddy.bigN))/bigN);
        }
        
        private double value() {
            return value(40);
        }
    }
    
    
    @Override
    public Card cardToPlay(TurnState state, CardSet hand) {
        // TODO Auto-generated method stub
        return null;
    }

    private Score randomlyEvaluate(Node n, CardSet hand) {
        TurnState tmpTS = n.ts;
        CardSet restrictedHand = hand;
        PlayerId playerToPlay;
        while(!tmpTS.isTerminal()) {
            
            try {
                playerToPlay = n.ts.nextPlayer();
            } catch(IllegalStateException e) {
                playerToPlay = n.ts.withTrickCollected().nextPlayer();
            }
            if(playerToPlay == ownName) {
                Card randomCard = restrictedHand.get(rng.nextInt(restrictedHand.size()));
                tmpTS = tmpTS.withNewCardPlayedAndTrickCollected(randomCard);
                restrictedHand = restrictedHand.remove(randomCard);
            } else {
                CardSet playableCards = tmpTS.unplayedCards().difference(hand);
                tmpTS = tmpTS.withNewCardPlayedAndTrickCollected(playableCards.get(rng.nextInt(playableCards.size())));
            }
            
        }
        return tmpTS.score();
        }

}
