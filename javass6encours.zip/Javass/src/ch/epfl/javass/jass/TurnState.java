package ch.epfl.javass.jass;

import ch.epfl.javass.Preconditions;
import ch.epfl.javass.jass.Card.Color;

public final class TurnState {
    private TurnState(long score, long unplayed, int trick) {
        this.currentPkScore = score;
        this.unplayedPkCardSet = unplayed;
        this.currentPkTrick = trick;
        
    }
    
    private long currentPkScore;
    private long unplayedPkCardSet;
    private int currentPkTrick;
    
    public static TurnState initial(Color trump, Score score, PlayerId firstPlayer) {
        return new TurnState(score.packed(), PackedCardSet.ALL_CARDS, PackedTrick.firstEmpty(trump, firstPlayer));
    }
    
    public static TurnState ofPackedComponents(long pkScore, long pkUnplayedCards, int pkTrick) {
        Preconditions.checkArgument(PackedScore.isValid(pkScore) && PackedCardSet.isValid(pkUnplayedCards) && PackedTrick.isValid(pkTrick));
        return new TurnState(pkScore, pkUnplayedCards, pkTrick);
    }
    
    public long packedScore() {
        return currentPkScore;
    }
    
    public long packedUnplayedCards() {
        return unplayedPkCardSet;
    }
    
    public int packedTrick() {
        return currentPkTrick;
    }
    
    public Score score() {
        return Score.ofPacked(currentPkScore);
    }
    
    public CardSet unplayedCards() {
        return CardSet.ofPacked(unplayedPkCardSet);
    }
    
    public Trick trick() {
        return Trick.ofPacked(currentPkTrick);
    }
    
    public boolean isTerminal() {
        return this.currentPkTrick == PackedTrick.INVALID;
    }
    
    public PlayerId nextPlayer() {
        if(PackedTrick.isFull(currentPkTrick)) throw new IllegalStateException();
        return PackedTrick.player(currentPkTrick, PackedTrick.size(currentPkTrick));
    }
    
    public TurnState withNewCardPlayed(Card card) {
        if(PackedTrick.isFull(currentPkTrick)) throw new IllegalStateException();
        return new TurnState(currentPkScore, PackedCardSet.remove(unplayedPkCardSet, card.packed()), PackedTrick.withAddedCard(currentPkTrick, card.packed()));
    }
    
    public TurnState withTrickCollected() {
        if(!PackedTrick.isFull(currentPkTrick)) throw new IllegalStateException();
        return new TurnState(PackedScore.withAdditionalTrick(currentPkScore, PackedTrick.winningPlayer(currentPkTrick).team(), PackedTrick.points(currentPkTrick)), unplayedPkCardSet, PackedTrick.nextEmpty(currentPkTrick));
    }
    
    public TurnState withNewCardPlayedAndTrickCollected(Card card) {
        if(PackedTrick.isFull(currentPkTrick)) throw new IllegalStateException();
        TurnState tmp = this.withNewCardPlayed(card);
        if(PackedTrick.isFull(tmp.packedTrick()))
            return tmp.withTrickCollected();
        return tmp;
        
    }
    
    
    
    
    
}