package ch.epfl.javass.net;

public  enum JassCommand {
    //the available commands to be sent and received through the network
    PLRS,
    TRMP,
    HAND,
    TRCK,
    CARD,
    SCOR,
    WINR
}
