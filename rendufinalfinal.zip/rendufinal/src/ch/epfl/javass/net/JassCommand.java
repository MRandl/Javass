package ch.epfl.javass.net;

/**
 * @author Mathis Randl (303140)
 * @author Aya Rahmoun (288078)
 */

public  enum JassCommand {
    //the available commands to be sent and received through the network
    PLRS,
    TRMP,
    HAND,
    TRCK,
    CARD,
    SCOR,
    WINR
}
