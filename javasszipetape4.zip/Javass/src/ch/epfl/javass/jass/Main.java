package ch.epfl.javass.jass;


/**
 * @author Mathis Randl
 *
 */
public class Main {
// /!\ IRRELEVANT DEBUGGING CLASS /!\
    public static void main(String[] args) {
        System.out.println(Integer.toBinaryString(PackedTrick.card((0b11010001000000110110110010000110), 0)));
        System.out.println(Integer.toBinaryString(PackedTrick.card((0b11010001000000110110110010000110), 1)));
        System.out.println(Integer.toBinaryString(PackedTrick.card((0b11010001000000110110110010000110), 2)));
        System.out.println(Integer.toBinaryString(PackedTrick.card((0b11010001000000110110110010000110), 3)));



        System.out.println(PackedTrick.winningPlayer(0b11010001000000110110110010000110));

        System.out.println(PackedTrick.winningPlayer(0b11010001000000110110110010000110));
    }
}
