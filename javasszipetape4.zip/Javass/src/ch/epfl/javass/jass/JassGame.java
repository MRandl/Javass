package ch.epfl.javass.jass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import ch.epfl.javass.jass.Card.Color;
import ch.epfl.javass.jass.Card.Rank;

public final class JassGame {
    public JassGame(long rngSeed, Map<PlayerId, Player> players, Map<PlayerId, String> playerNames) {
        Random rng = new Random(rngSeed);
        this.shuffleRng = new Random(rng.nextLong());
        this.trumpRng = new Random(rng.nextLong());
        this.names = Collections.unmodifiableMap(new EnumMap<>(playerNames));
        this.players = Collections.unmodifiableMap(new EnumMap<>(players));
        this.score = Score.INITIAL;
        
    }
    
    private Score score;
    private int[] cards = new int[4];
    private Map<PlayerId, String> names; 
    private Map<PlayerId, Player> players;
    private Random shuffleRng;
    private Random trumpRng;
    private TurnState turnstate;
    
    boolean isGameOver() {
        return score.totalPoints(TeamId.TEAM_1) >= Jass.WINNING_POINTS || 
               score.totalPoints(TeamId.TEAM_2) >= Jass.WINNING_POINTS;
    }
    
    private List<Card> deckShuffler() {
        List<Card> deck = new ArrayList<>();
        for(int color = 0; color < 9; ++color)
            for(int rank = 0; rank < 3; ++ rank)
                deck.add(Card.of(Color.ALL.get(color), Rank.ALL.get(rank)));
        Collections.shuffle(deck, shuffleRng);
        for(short i = 0; i < 4; ++i)
            cards[i] = (int) CardSet.of(deck.subList(i*9,(i+1)*9 -1)).packed();
        return deck;
    }
      
    public void advanceToEndOfNextTrick() {
        for(short i = 0; i< 4; ++i) {
            players.get(PlayerId.values()[i]).updateHand(CardSet.ofPacked(cards[i]));
        }
        
    }

}
