package ch.epfl.javass.net;

import java.util.Base64;

public final class StringSerializer {
    private StringSerializer(){}

    //NO PUBLIC/PRIVATE IDENTIFIERS ON THESE ON PURPOSE
    static String serializeLong(long l){
        return Long.toHexString(l);
    }

    static String serializeInt(int i){
        return Integer.toHexString(i);
    }

    static long deserializeLong(String s){
        return Long.parseUnsignedLong(s, 16);
    }

    static int deserializeInt(String s){
        return Integer.parseUnsignedInt(s, 16);
    }

    static String serializeString(String s){
        return Base64.getEncoder().encodeToString(s.getBytes());
    }

    static String deserializeString(String s){
        return new String(Base64.getDecoder().decode(s));
    }

    static String theJoiner(char c, String ... values){
        return  String.join(Character.toString(c), values);
    }

    static String[] theSplitter(char c, String joinedValues){ return joinedValues.split(Character.toString(c)); }
}

