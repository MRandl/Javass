package ch.epfl.javass.gui;

import ch.epfl.javass.jass.TeamId;
import javafx.beans.property.*;


public final class ScoreBean {
    private SimpleIntegerProperty
            turnPoints1 = new SimpleIntegerProperty(),
            gamePoints1 = new SimpleIntegerProperty(),
            totalPoints1 = new SimpleIntegerProperty(),
            turnPoints2 = new SimpleIntegerProperty(),
            gamePoints2 = new SimpleIntegerProperty(),
            totalPoints2 = new SimpleIntegerProperty();
    private SimpleObjectProperty<TeamId> winningTeam = new SimpleObjectProperty<>();

    ReadOnlyIntegerProperty turnPointsProperty(TeamId t){
        return t == TeamId.TEAM_1 ? turnPoints1 : turnPoints2;
    }

    void setTurnPoints(TeamId t, int newTurnPoints){
        if (t == TeamId.TEAM_1) turnPoints1.set(newTurnPoints);
        else turnPoints2.set(newTurnPoints);
    }

    ReadOnlyIntegerProperty gamePointsProperty(TeamId t){
        return t == TeamId.TEAM_1 ? gamePoints1 : gamePoints2;
    }

    void setGamePoints(TeamId t, int newTurnPoints){
        if (t == TeamId.TEAM_1) gamePoints1.set(newTurnPoints);
        else gamePoints2.set(newTurnPoints);
    }

    ReadOnlyIntegerProperty totalPointsProperty(TeamId t){
        return t == TeamId.TEAM_1 ? totalPoints1 : totalPoints2;
    }

    void setTotalPoints(TeamId t, int newTurnPoints){
        if (t == TeamId.TEAM_1) totalPoints1.set(newTurnPoints);
        else totalPoints2.set(newTurnPoints);
    }

    ReadOnlyObjectProperty<TeamId> winningTeamProperty(){
        return winningTeam;
    }

    void setWinningTeam(TeamId t){
        winningTeam.set(t);
    }
}
