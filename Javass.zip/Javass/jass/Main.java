package ch.epfl.javass.jass;


import java.util.Random;

/**
 * @author Mathis Randl
 *
 */
public class Main {
// /!\ IRRELEVANT DEBUGGING CLASS /!\
    public static void main(String[] args) {
        Random rng = new Random(2019);
        Random trash = new Random(rng.nextLong());
        Random shuffleRng = new Random(rng.nextLong());
        for(int i = 0; i < 24; ++i){
            System.out.println(Card.Color.ALL.get(shuffleRng.nextInt(4)));
        }
    }
}
